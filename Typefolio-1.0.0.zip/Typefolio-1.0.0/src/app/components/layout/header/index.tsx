import AnnouncementBar from "./announcementBar"

const Header = () => {
    return (
        <header>
            <AnnouncementBar/>
        </header>
    )
}

export default Header